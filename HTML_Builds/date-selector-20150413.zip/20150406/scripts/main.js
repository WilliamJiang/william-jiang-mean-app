$(function() {
	// Toggle collapse/expand left sidebar
	var $wrapper = $('.wrapper');
	$('.user-collapsed').click(function() {
		if ($wrapper.hasClass('collapsed')) {
			$wrapper.removeClass('collapsed');

		} else {
			$wrapper.addClass('collapsed');
		}
	});

	// Set height for main content based on brower's height
	var browerHeight;
	function setHeight() {
		var $sidebar = $('.sidebar-info'),
				userInfoHeight = $('.user-info').height();
		browerHeight = $(window).height();
		// Update height for sidebar & content when resize
		$('.content').css('height', browerHeight);
		$sidebar.css('height', browerHeight - userInfoHeight);
	}
	setHeight();
	// Update height of content when resize
	$(window).on('resize', function() {
		setHeight();
	});

	// Init scroll for sidebar
	$('.sidebar-info').jScrollPane({
		verticalGutter: 0,
		autoReinitialise			: true,
		autoReinitialiseDelay		: 100
	});

	// Init scroll each time click on CI
	$('.ci').click(function() {
		// Using scroll bar revision versions list
		$('.version-list').jScrollPane({
			verticalGutter: 0,
			autoReinitialise			: true,
			autoReinitialiseDelay		: 100
		});
	});



	// Change view CI list mode
	var $viewListBtn = $('.view-mode .btn'),
			$mainContent = $('.main-content');
	$viewListBtn.click(function(e) {
		var $target = $(e.target).closest('.btn');
		$viewListBtn.removeClass('selected');
		$target.addClass('selected');
		if ($target.hasClass('btn-list')) {
			$mainContent.addClass('list-view');
		} else {
			$mainContent.removeClass('list-view');
		}
	});


	// Toggle show more/less filter
	$libraryHeader = $('.content-header-library');
	var $moreFilter = $('.more');
	$moreFilter.click(function() {
		if ($libraryHeader.hasClass('show-more')) {
			$moreFilter.html('More filters');
			$libraryHeader.removeClass('show-more');
		} else {
			$moreFilter.html('Less Filters');
			$libraryHeader.addClass('show-more');
		}
	});

	// CI Details behavior

	// var $annotation = $('.annotation');
	$('.ci-detail .annotation .buttons-collapsed-ci').click(function(e) {
		var $annotation = $(e.target).closest('.annotation');

		if ($annotation.hasClass('collapsed')) {
			$annotation.removeClass('collapsed');
		} else {
			$annotation.addClass('collapsed');
		}
	});

	// Collapse/Expand mode of revision version panel
	var $revisionPanel = $('.ci-detail .revision-version');
	$('.ci-detail .revision-version .buttons-collapsed-ci').click(function(e) {
		var $revision = $(e.target).closest('.revision-version');
		if ($revision.hasClass('collapsed')) {
			$revision.removeClass('collapsed');
		} else {
			$revision.addClass('collapsed');
		}
	});

	// Implement click on Compare button to display Revision version Select mode
	var $compareRevision = $('.compare-revision');
	$('.btn-compare').click(function() {
		if ($revisionPanel.hasClass('select-mode')) {
			$compareRevision.modal('show');
			$revisionPanel.removeClass('select-mode');
		} else {
			$revisionPanel.addClass('select-mode');
		}
	});

	// Implement click on Edit link to enable Textare, "Cancel" and "Save" button
	var $notes = $('.revision-meta .notes');
	$('.revision-meta .edit').click(function() {
		if ($notes.hasClass('is-editing')) {
			$notes.removeClass('is-editing');
		} else {
			$notes.addClass('is-editing');
		}
	});

	$('.revision-meta .notes .btn-cancel').click(function() {
		$notes.removeClass('is-editing');
	})

	// Click on each revision version
	var $versionItems = $('.version-item');
	$('.version-item').click(function(e) {
		var $target = $(e.target).closest('.version-item');
		if (!$target.hasClass('in-active') && $revisionPanel.hasClass('select-mode')) {
			if ($target.hasClass('is-selected')) {
				$target.removeClass('is-selected');
			} else {
				$target.addClass('is-selected');
			}
			// $target.find('input').attr('checked', 'checked');
		}
	});

	// Click on radio buttons to show/hide content on CI-details
	var $stagpleOpt = $('.staple-option');
	$('.radio-btn').click(function(e) {
		var $target = $(e.target),
				val = $target.closest('.staple-btn').val();
		if (val === 'yes') {
			$stagpleOpt.removeClass('active-no');
			$stagpleOpt.addClass('active-yes');
		} else {
			$stagpleOpt.removeClass('active-yes');
			$stagpleOpt.addClass('active-no');

		}
	});

	// Close compare revision fix can not scroll when open more than 2 bootstrap modals
	$body = $('body');
	$('.modal').on('hidden.bs.modal', function (event) {
		var backDrop = $('.modal-backdrop');
		if (backDrop && backDrop.length >= 1) {
			$body.addClass('modal-open');
		}
	});

	// Disable click blur to close dropdown
	var $dropdown = $('.dropdown');
	$('.dropdown.keep-open').on({
    "shown.bs.dropdown": function(e) {
			$dropdown.removeClass('open');
			$(e.target).closest('.dropdown').addClass('open');
			this.closable = false;
    },
		"click": function(e) {
			$target = $(e.target);
			if ($target.hasClass('btn-primary') || $target.hasClass('btn-dropdown') || $target.hasClass('btn-ok')) {
				this.closable = true;
			} else {
				this.closable = false;
			}
    },
    "hide.bs.dropdown": function() {
			return this.closable;
    }
	});

});