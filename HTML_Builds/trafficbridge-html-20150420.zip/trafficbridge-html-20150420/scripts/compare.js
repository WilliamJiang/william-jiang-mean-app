$(function() {
	$('.annotation .buttons-collapsed-ci').click(function(e) {
		var $annotation = $(e.target).closest('.annotation');
		$annotation.toggleClass('collapsed');
	});

	$('.revision-version .buttons-collapsed-ci').click(function(e) {
		var $revisionVersion = $(e.target).closest('.revision-version');
		$revisionVersion.toggleClass('collapsed');
	});

	var $CIDocuments = $('.ci-document-container'),
			$pdfViewersCI = $('.compare-ci-screen .wrapper-pdf-placeholder'),
			$versionList = $('.version-list'),
			$pdfViewersRV = $('.compare-revision .wrapper-pdf-placeholder');
	
	function updateDocumentWidth() {
		var $CIDocument = $('.ci-document-container-first'),
				$revisionCompareCI = $('.compare-ci-screen .revision-content'),
				$compareRV = $('.compare-revision'),
				$CIHeader = $('.ci-compare-header'),
				$meta = $CIDocument.find('.revision-meta'),
				$groupActions = $CIDocument.find('.group-action'),
				$annotation = $CIDocuments.find('.annotation'),
				$compareRVWrapper = $('.compare-version-current'),
				$RVBar = $compareRVWrapper.find('.revision-version'),
				$compareRVContent = $compareRVWrapper.find('.content-compare-version-current'),
				$RVActions = $('.compare-version-next .compare-action'),
				$RVGroupActions = $compareRV.find('.compare-version-next .group-action'),
				$RVHeader = $compareRV.find('.compare-header'),
				$RVNotify = $compareRV.find('.compare-notify'),
				$RVAside = $compareRV.find('.revision-version'),
				$RVList = $RVAside.find('.version-list'),
				browerHeight = $(window).height(),
				pdfHeight = browerHeight - $CIHeader.height() - $meta.height() - $groupActions.height() - 47;

		$pdfViewersCI.css('height', pdfHeight);
		$annotation.css('height', $revisionCompareCI.height());
		// delay a bit for re-update
		setTimeout(function() {
			$revisionCompareCI.css('width', $CIDocument.width() - 30 - 10);
			$compareRVContent.css('width', $('.compare-version-current').width() - 30 - 10);
		}, 10);
		$pdfViewersRV.css('height', browerHeight - $RVHeader.height() - $RVNotify.height() -$RVGroupActions.height() - $RVActions.height() - 105);
		$RVAside.css('height', $compareRVWrapper.height());
		$RVList.css('height', $RVAside.height() - $RVAside.find('.revision-fixed-top').height() - $RVAside.find('.revision-fixed-bottom').height() );

	}
	updateDocumentWidth();
	// Scroll for dropdown pdf reader
	$pdfViewersCI
		.jScrollPane({
			verticalGutter: 0,
			autoReinitialise			: true,
			autoReinitialiseDelay		: 100
		});

	$pdfViewersRV
		.jScrollPane({
			verticalGutter: 0,
			autoReinitialise			: true,
			autoReinitialiseDelay		: 100
		});

	$versionList
		.jScrollPane({
			verticalGutter: 0,
			autoReinitialise			: true,
			autoReinitialiseDelay		: 100
		});

	$(window).on('resize', function() {
		updateDocumentWidth();
	});
});