$(function() {
	$('.annotation .buttons-collapsed-ci').click(function(e) {
		var $annotation = $(e.target).closest('.annotation');
		$annotation.toggleClass('collapsed');
	});

	$('.revision-version .buttons-collapsed-ci').click(function(e) {
		var $revisionVersion = $(e.target).closest('.revision-version');
		$revisionVersion.toggleClass('collapsed');
	});

	var $CIDocuments = $('.ci-document-container'),
			$pdfViewersCI = $('.compare-ci-screen .wrapper-pdf-placeholder'),
			$versionList = $('.version-list'),
			$pdfViewersRV = $('.compare-revision .wrapper-pdf-placeholder');

	// updated Width of Revision Content
	function updateCIDocumentWidth() {
		var $CIDocumentContainer = $('.ci-document-container'),
				$RevisionContainer = $('.compare-ci-screen .revision-content'),
				ciPadding = 35,
				widthCIDocument =  ($CIDocumentContainer.width() - ciPadding - 60 ) / 2;

		$RevisionContainer.css('width', widthCIDocument);
		
		// delay a bit for re-update
		// setTimeout(function() {
		// 	$RevisionContainer.css('width', widthCIDocument);
		// }, 10);
	}	
	
	function updateDocumentWidth() {
		var $CIDocument = $('.ci-document-container-first'),
				$revisionCompareCI = $('.compare-ci-screen .revision-content'),
				$compareRV = $('.compare-revision'),
				$CIHeader = $('.ci-compare-header'),
				$meta = $CIDocument.find('.revision-meta'),
				$notify = $compareRV.find('.compare-notify-wrapper'),
				$versionInfo = $compareRV.find('.version-info'),
				$groupActions = $CIDocument.find('.group-action'),
				$annotation = $CIDocuments.find('.annotation'),
				$compareRVWrapper = $('.compare-version-current'),
				$RVBar = $compareRVWrapper.find('.revision-version'),
				$compareRVContent = $compareRVWrapper.find('.content-compare-version-current'),
				$RVActions = $('.compare-version-next .compare-action'),
				$RVGroupActions = $compareRV.find('.compare-version-next .group-action'),
				$RVHeader = $compareRV.find('.compare-header'),
				$RVNotify = $compareRV.find('.compare-notify'),
				$RVAside = $compareRV.find('.revision-version'),
				$RVList = $RVAside.find('.version-list'),
				browerHeight = $(window).height(),
				pdfHeight = browerHeight - $CIHeader.height() - $meta.height() - $groupActions.height() - 47;

		$pdfViewersCI.css('height', pdfHeight);
		$annotation.css('height', $revisionCompareCI.height());

		// delay a bit for re-update
		// setTimeout(function() {
		// 	$revisionCompareCI.css('width', $CIDocument.width() - 30 - 10);
		// 	$compareRVContent.css('width', $('.compare-version-current').width() - 30 - 10);
		// }, 10);

		$pdfViewersRV.css('height', browerHeight - $RVHeader.height() - $notify.height() - $groupActions.height() - $versionInfo.height() - 62);
		$RVAside.css('height', $compareRVWrapper.height() - $versionInfo.height() - 32);
		$RVList.css('height', $RVAside.height() - $RVAside.find('.revision-fixed-top').height() - $RVAside.find('.revision-fixed-bottom').height() );

	}

	// Update width of input when resize browser
	function updateInputRVWidth() {
		var $optionNo = $('.compare-option .option-no'),
				$radioInline = $('.compare-notify-wrapper .option-no .radio-inline'),
				$compareOption = $('.compare-notify-wrapper .compare-option'),
				$input = $('.option-no .enter-reason'),
				inputWidth = $optionNo.width() - 86 - 20;
		
		$input.css('width', inputWidth);
	}

	// Update Width of Compare Version when resize browser
	function updateCompareRVWidth() {
		var $versionNext = $('.compare-revision .compare-version-next'),
				$versionCurrent = $('.compare-revision .compare-version-current'),
				browserWidth = $(window).width();
				versionWidth = (browserWidth - 50) / 2;

		$versionNext.css('width', versionWidth);
		$versionCurrent.css('width', versionWidth);
	}

	updateCIDocumentWidth();
	updateDocumentWidth();
	updateInputRVWidth();
	updateCompareRVWidth();

	// Scroll for dropdown pdf reader
	$pdfViewersCI
		.jScrollPane({
			verticalGutter: 0,
			autoReinitialise			: true,
			autoReinitialiseDelay		: 100
		});

	$pdfViewersRV
		.jScrollPane({
			verticalGutter: 0,
			autoReinitialise			: true,
			autoReinitialiseDelay		: 100
		});

	$versionList
		.jScrollPane({
			verticalGutter: 0,
			autoReinitialise			: true,
			autoReinitialiseDelay		: 100
		});

	$(window).on('resize', function() {
		updateCIDocumentWidth();
		updateDocumentWidth();
		updateInputRVWidth();
		updateCompareRVWidth();
	});
});