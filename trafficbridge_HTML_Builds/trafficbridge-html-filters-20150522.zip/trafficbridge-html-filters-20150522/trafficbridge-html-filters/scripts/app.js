// AGILITYIO : Mokcing data
var myApp = angular.module( "myApp", ['isteven-multi-select' ]);

myApp.controller('MainCtrl',
  function($scope) {
    $scope.listMockdata = [
      {                     
        name: 'All',
        ticked: true
      },
      {                     
        name: "Hershey's (32)",
        ticked: true
      },
      {                     
        name: "Disney (23)",
        ticked: true
      },
      {                     
        name: 'proctor & gamble',
        ticked: true
      },
      {                     
        name: 'american express',
        ticked: true
      },
      {                     
        name: 'paramount (17)',
        ticked: true
      },
      {                     
        name: 'ford motors (12)',
        ticked: true
      },
      {                     
        name: "Disney (23)",
        ticked: true
      },
      {                     
        name: 'american express',
        ticked: true
      },
      {                     
        name: 'ford motors (12)',
        ticked: true
      },
      {                     
        name: "Disney (23)",
        ticked: true
      }
    ];
  });