// Toggle collapse/expand left sidebar
var $wrapper = $('.wrapper');
$('.user-collapsed').click(function() {
	console.log('clicked');
	if ($wrapper.hasClass('collapsed')) {
		$wrapper.removeClass('collapsed');

	} else {
		$wrapper.addClass('collapsed');
	}
});

// Using iScroll for style scrolling bar
// Check it at: http://cubiq.org/iscroll-4
var scroll = new iScroll('ci-list', {
	scrollbarClass: 'CIListbar'
});

// Change view CI list mode
var $viewListBtn = $('.view-mode .btn'),
		$mainContent = $('.main-content');
$viewListBtn.click(function(e) {
	var $target = $(e.target).closest('.btn');
	$viewListBtn.removeClass('selected');
	$target.addClass('selected');
	if ($target.hasClass('btn-list')) {
		$mainContent.addClass('list-view');
	} else {
		$mainContent.removeClass('list-view');
	}
	// Refresh scroll
	scroll.refresh();
});


// Toggle show more/less filter
$libraryHeader = $('.content-header-library');
var $moreFilter = $('.more');
$moreFilter.click(function() {
	if ($libraryHeader.hasClass('show-more')) {
		$moreFilter.html('More Filter');
		$libraryHeader.removeClass('show-more');
	} else {
		$moreFilter.html('Less Filter');
		$libraryHeader.addClass('show-more');
	}
});