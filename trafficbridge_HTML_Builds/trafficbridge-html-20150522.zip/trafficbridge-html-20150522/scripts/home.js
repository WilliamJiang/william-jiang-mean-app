// Init scroll
$(function() {
	$('.content')
		.jScrollPane({
			verticalGutter: 0,
			autoReinitialise			: true,
			autoReinitialiseDelay		: 100,
			contentWidth: '0px'
		});

	//Scroll for New CI 
	$('.instruction-pdf')
		.jScrollPane({
			verticalGutter: 0,
			autoReinitialise			: true,
			autoReinitialiseDelay		: 100
		});
		
	//Scroll for dropdown Advertiser		
	$('.list-select')
		.jScrollPane({
			verticalGutter: 0,
			autoReinitialise			: true,
			autoReinitialiseDelay		: 100
		});

	$('.wrap-annotation-list')
		.jScrollPane({
			verticalGutter: 0,
			autoReinitialise			: true,
			autoReinitialiseDelay		: 100
		});

		$('.wrap-panel-list')
			.jScrollPane({
				verticalGutter: 0,
				autoReinitialise			: true,
				autoReinitialiseDelay		: 100
			});
});
