// Init scroll
$(function() {
	$('.content')
		.jScrollPane({
			verticalGutter: 0,
			autoReinitialise			: true,
			autoReinitialiseDelay		: 100
		});
});